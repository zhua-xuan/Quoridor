#include "MyPlayer.h"
#include <cstring>
#include <queue>
#include <algorithm>
#include <chrono>
#include <iostream>
#include <cstdlib>
#include <ctime>

namespace QuoridorUtils {
    bool vst[9][9] = { 0 };

    int dir[4][2] = { 0,1,0,-1,-1,0,1,0 };

    State q;

    Location MyPlayer::where_go(Location my, const Location enem)
    {
        int compare[4] = { 10000,10000,10000,10000 };
        Location temp;
        if (is_may(my, 1) == 1)
        {
            if (enem.x == my.x && enem.y == my.y + 1)
            {
                if (is_may(enem, 1) == 1)
                {
                    temp.x = my.x;
                    temp.y = my.y + 2;
                    q_reset(temp);
                    compare[0] = BFS_step(q, targetY);
                }
                else
                {
                    compare[0] = 10000;
                }
            }
            else
            {
                temp.x = my.x;
                temp.y = my.y + 1;
                q_reset(temp);
                compare[0] = BFS_step(q, targetY);
            }
        }
        if (is_may(my, 2) == 1)
        {
            if (enem.x == my.x && enem.y == my.y - 1)
            {
                if (is_may(enem, 2) == 1)
                {
                    temp.x = my.x;
                    temp.y = my.y - 2;
                    q_reset(temp);
                    compare[1] = BFS_step(q, targetY);
                }
                else
                {
                    compare[1] = 10000;
                }
            }
            else
            {
                temp.x = my.x;
                temp.y = my.y - 1;
                q_reset(temp);
                compare[1] = BFS_step(q, targetY);
            }
        }
        if (is_may(my, 3) == 1)
        {
            if (enem.y == my.y && enem.x == my.x - 1)
            {
                if (is_may(enem, 3) == 1)
                {
                    temp.x = my.x - 2;
                    temp.y = my.y;
                    q_reset(temp);
                    compare[2] = BFS_step(q, targetY);
                }
                else
                {
                    compare[2] = 10000;
                }
            }
            else
            {
                temp.x = my.x - 1;
                temp.y = my.y;
                q_reset(temp);
                compare[2] = BFS_step(q, targetY);
            }
        }
        if (is_may(my, 4) == 1)
        {
            if (enem.y == my.y && enem.x == my.x + 1)
            {
                if (is_may(enem, 4) == 1)
                {
                    temp.x = my.x + 2;
                    temp.y = my.y;
                    q_reset(temp);
                    compare[3] = BFS_step(q, targetY);
                }
                else
                {
                    compare[3] = 10000;
                }
            }
            else
            {
                temp.x = my.x + 1;
                temp.y = my.y;
                q_reset(temp);
                compare[3] = BFS_step(q, targetY);
            }
        }
        int min = 10000;
        int jil = 4;
        for (int i = 0; i < 4; i++)
        {
            if (compare[i] < min)
            {
                min = compare[i];
                jil = i;
            }
        }
        if (jil == 0)
        {
            if (enem.x == my.x && enem.y == my.y + 1)
            {
                if (is_may(enem, 1) == 1)
                {
                    temp.x = my.x;
                    temp.y = my.y + 2;
                    return temp;
                }
            }
            else
            {
                temp.x = my.x;
                temp.y = my.y + 1;
                return temp;
            }
        }
        if (jil == 1)
        {
            if (enem.x == my.x && enem.y == my.y - 1)
            {
                if (is_may(enem, 2) == 1)
                {
                    temp.x = my.x;
                    temp.y = my.y - 2;
                    return temp;
                }
            }
            else
            {
                temp.x = my.x;
                temp.y = my.y - 1;
                return temp;
            }
        }
        if (jil == 2)
        {
            if (enem.y == my.y && enem.x == my.x - 1)
            {
                if (is_may(enem, 3) == 1)
                {
                    temp.x = my.x - 2;
                    temp.y = my.y;
                    return temp;
                }
            }
            else
            {
                temp.x = my.x - 1;
                temp.y = my.y;
                return temp;
            }
        }
        if (jil == 3)
        {

            if (enem.y == my.y && enem.x == my.x + 1)
            {
                if (is_may(enem, 4) == 1)
                {
                    temp.x = my.x + 2;
                    temp.y = my.y;
                    return temp;
                }
            }
            else
            {
                temp.x = my.x + 1;
                temp.y = my.y;
                return temp;
            }
        }
    }

    int MyPlayer::decide_rp(const Location my, const Location enem)
    {
        if (blocksum <= 0)
        {
            return 1;
        }
        if (step_num <= 4)
        {
            return 1;//�ƶ�����
        }
        if (step_num == 4 || step_num == 5)
        {
            return 2;
        }
        q_reset(my);
        int a = BFS_step(q, targetY);
        q_reset(enem);
        a = a - BFS_step(q, targetE);
        if (a <= 0)
        {
            return 1;
        }
        else
        {
            return 2;
        }
    }

    void MyPlayer::q_reset(const Location& Loc)
    {
        q.x = Loc.x;
        q.y = Loc.y;
        q.Step_Counter = 0;
    }//�������·��ǰһ��Ҫʹ������ʼ��

    BlockBar MyPlayer::generate_bar(const Location enemyloc, const Location myloc)
    {
        int youxiu[8] = { 0 };
        BlockBar temp;
        temp.start.x = enemyloc.x - 1;
        temp.stop.x = enemyloc.x + 1;
        temp.start.y = enemyloc.y - 1;
        temp.stop.y = enemyloc.y - 1;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[0] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x - 2;
        temp.stop.x = enemyloc.x;
        temp.start.y = enemyloc.y - 1;
        temp.stop.y = enemyloc.y - 1;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[1] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x - 1;
        temp.stop.x = enemyloc.x + 1;
        temp.start.y = enemyloc.y;
        temp.stop.y = enemyloc.y;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[2] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x - 2;
        temp.stop.x = enemyloc.x;
        temp.start.y = enemyloc.y;
        temp.stop.y = enemyloc.y;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[3] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x - 1;
        temp.stop.x = enemyloc.x - 1;
        temp.start.y = enemyloc.y - 2;
        temp.stop.y = enemyloc.y;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[4] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x - 1;
        temp.stop.x = enemyloc.x - 1;
        temp.start.y = enemyloc.y - 1;
        temp.stop.y = enemyloc.y + 1;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[5] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x;
        temp.stop.x = enemyloc.x;
        temp.start.y = enemyloc.y - 1;
        temp.stop.y = enemyloc.y + 1;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[6] = ability_block(temp, enemyloc);
            }
        }
        temp.start.x = enemyloc.x;
        temp.stop.x = enemyloc.x;
        temp.start.y = enemyloc.y - 2;
        temp.stop.y = enemyloc.y;
        select_bar.push_back(temp);
        if (!temp.isNan())
        {
            if ((is_hefa(temp, enemyloc, myloc)) == 1)
            {
                youxiu[7] = ability_block(temp, enemyloc);
            }
        }
        int min = 0;
        int jil = 8;
        for (int i = 0; i < 8; i++)
        {
            if (youxiu[i] > min)
            {
                min = youxiu[i];
                jil = i;
            }
        }
        if (jil == 8)
        {
            Location shibail;
            return shibail;
        }
        return select_bar[jil];
    }

    int MyPlayer::is_may(const Location& Loc, int direction)
    {
        if (direction == 1)//��
        {
            if (Loc.y < SIZE)
            {
                for (auto block : this->blocks)
                {
                    if (block.isH())
                    {
                        if (block.start.x == Loc.x - 1 || block.start.x == Loc.x - 2)
                            if (block.start.y == Loc.y)
                            {
                                return 0;
                            }
                    }
                }
                return 1;
            }
            else
            {
                return 0;
            }
        }
        if (direction == 2)//��
        {
            if (Loc.y > 1)
            {
                for (auto block : this->blocks)
                {
                    if (block.isH())
                    {
                        if (block.start.x == Loc.x - 1 || block.start.x == Loc.x - 2)
                            if (block.start.y == Loc.y - 1)
                            {
                                return 0;
                            }
                    }
                }
                return 1;
            }
            else
            {
                return 0;
            }
        }
        if (direction == 3)//��
        {
            if (Loc.x > 1)
            {
                for (auto block : this->blocks)
                {
                    if (block.isV())
                    {
                        if (block.start.y == Loc.y - 1 || block.start.y == Loc.y - 2)
                            if (block.start.x == Loc.x - 1)
                            {
                                return 0;
                            }
                    }
                }
                return 1;
            }
            else
            {
                return 0;
            }
        }
        if (direction == 4)//��
        {
            if (Loc.x < SIZE)
            {
                for (auto block : this->blocks)
                {
                    if (block.isV())
                    {
                        if (block.start.y == Loc.y - 1 || block.start.y == Loc.y - 2)
                            if (block.start.x == Loc.x)
                            {
                                return 0;
                            }
                    }
                }
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }

    int MyPlayer::BFS_step(State st, int targets)
    {
        for (int a = 0; a < 9; a++)
        {
            for (int b = 0; b < 9; b++)
            {
                vst[a][b] = 0;
            }
        }
        std::queue <State> m; // BFS ����
        State now, next; // ����2 ��״̬����ǰ����һ��
        st.Step_Counter = 0; // ����������
        m.push(st); // ���
        vst[st.x - 1][st.y - 1] = 1; // ���ʱ��
        while (!m.empty())
        {
            now = m.front(); // ȡ����Ԫ�ؽ�����չ
            if (now.y == targets) // ����Ŀ��̬����ʱΪStep_Counter ����Сֵ�������˳�����
            {
                return now.Step_Counter;
            }
            for (int i = 0; i < 4; i++)
            {
                next.x = now.x + dir[i][0]; // ���չ���������һ��״̬
                next.y = now.y + dir[i][1];
                next.Step_Counter = now.Step_Counter + 1; // ��������1
                Location temp;
                temp.x = now.x;
                temp.y = now.y;
                if (is_may(temp, i + 1) && vst[next.x - 1][next.y - 1] == 0) // ���״̬����Լ�����������
                {
                    m.push(next);
                    vst[next.x - 1][next.y - 1] = 1; //���ʱ��
                }
            }
            m.pop(); // ����Ԫ�س���
        }
        return 0;
    }

    int MyPlayer::is_hefa(const BlockBar& newb, const Location& enem, const Location& myloc)//�жϵ����Ƿ�Ϸ�
    {
        blocks.push_back(newb);
        q_reset(enem);
        if (BFS_step(q, targetE) == 0)
        {
            blocks.pop_back();
            return 0;
        }
        q_reset(myloc);
        if (BFS_step(q, targetY) == 0)
        {
            blocks.pop_back();
            return 0;
        }
        blocks.pop_back();
        if (newb.isH())
        {
            for (auto block : this->blocks)
            {
                if (block.isH())
                {
                    if (block.start.y == newb.start.y)
                    {
                        if (block.start.x == newb.start.x || block.start.x == newb.start.x - 1 || block.start.x == newb.start.x + 1)
                        {
                            return 0;
                        }
                    }
                }
            }
            return 1;
        }
        if (newb.isV())
        {
            for (auto block : this->blocks)
            {
                if (block.isV())
                {
                    if (block.start.x == newb.start.x)
                    {
                        if (block.start.y == newb.start.y || block.start.y == newb.start.y - 1 || block.start.y == newb.start.y + 1)
                        {
                            return 0;
                        }
                    }
                }
            }
            return 1;
        }
        return 0;
    }

    int MyPlayer::ability_block(const BlockBar& newb, const Location enem_location)
    {
        q_reset(enem_location);
        int temp = BFS_step(q, targetE);
        blocks.push_back(newb);
        q_reset(enem_location);
        temp = BFS_step(q, targetE) - temp;
        blocks.pop_back();
        return temp;
    }


    Step MyPlayer::nextStep(const ChessboardChange& newChange) {
        if (this->targetY == 0) {
            step_num = 0;
            blocksum = 10;
            if (newChange.myLoc == PLAYER0_LOC) {                // ������ʼ����Ϊ (5,1) ��Ŀ��Ϊ (x,9) 
                this->targetY = PLAYER1_LOC.y;
                this->targetE = PLAYER0_LOC.y;
            }
            else {                                             // ������ʼ����Ϊ (5,9) ��Ŀ��Ϊ (x,1) 
                this->targetY = PLAYER0_LOC.y;
                this->targetE = PLAYER1_LOC.y;
            }
        }
        std::cout << newChange<<std::endl;                                  // ������յ������ݵ�����̨��ʾ 
        if (!newChange.newEnemyBlockBar.isNan()) {               // �Է������˵��� 
            BlockBar tmp = newChange.newEnemyBlockBar;
            tmp.normalization();                                 // �淶Ϊ start ����С�� stop �������ʽ 
            this->blocks.push_back(tmp);                         // �洢�淶���� 
        }
        step_num++;
        if (decide_rp(newChange.myLoc, newChange.enemyLoc) == 1)
        {
            Location result = where_go(newChange.myLoc, newChange.enemyLoc);
            Step step;
            step.myNewLoc = result;
            return step;
        }
        else
        {
            Step step;
            BlockBar chenggongt;
            chenggongt = generate_bar(newChange.enemyLoc, newChange.myLoc);
            if (chenggongt.isNan() == 1)
            {
                select_bar.clear();
                Location result = where_go(newChange.myLoc, newChange.enemyLoc);
                step.myNewLoc = result;
                return step;
            }
            step.myNewBlockBar = chenggongt;
            blocks.push_back(step.myNewBlockBar);
            select_bar.clear();
            blocksum--;
            return step;
        }
    }

    void MyPlayer::restart() {
        blocksum = 0;
        this->blocks.clear();
        this->select_bar.clear();
        this->targetY = 0;
        this->targetE = 0;
        for (int a = 0; a++; a < 9)
        {
            for (int b = 0; b++; b < 9)
            {
                vst[a][b] = 0;
            }
        }
        q.x = 0;
        q.y = 0;
        q.Step_Counter = 0;
    }
}


