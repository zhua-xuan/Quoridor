#pragma once
#include <vector>
#include <cstring>
#include <queue>
#include <algorithm>
#include "Player.h"

namespace QuoridorUtils {
    struct State // BFS �����е�״̬���ݽṹ
    {
        int x, y; // ����λ��
        int Step_Counter; // ��������ͳ����
    };

    class MyPlayer final : public Player {
    private:
        int blocksum;
        std::vector<BlockBar> blocks;
        std::vector<BlockBar> select_bar;
        int targetY = 0;
        int targetE = 0;
        int step_num;
    public:
        void q_reset(const Location& Loc);
        BlockBar generate_bar(const Location enemyloc, const Location myloc);
        Location where_go(const Location my, const Location enem);
        int decide_rp(const Location my, const Location enem);
        int is_hefa(const BlockBar& newb, const Location& enem, const Location& myloc);
        int ability_block(const BlockBar& newb, const Location enem_location);
        int is_may(const Location& Loc, int direction);
        int BFS_step(State st, int targets);
        MyPlayer(const std::string& key) : Player(key) {};            // �������, �����޸� 
        Step nextStep(const ChessboardChange& newChange) override;    // ��������ʵ�� 
        void restart() override;                                      // ��������ʵ�� 
    };
}
